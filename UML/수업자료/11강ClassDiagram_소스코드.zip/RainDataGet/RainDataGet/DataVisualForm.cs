﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StandardLibrary;

namespace RainDataGet
{
    public partial class DataVisualForm : Form
    {

        public DeviceManager m_DeviceManager;
        public LogCreator m_LogCreator;
        public DataVisualForm()
        {
            InitializeComponent();

            DeviceManager.GetInstance().Init();


            //특정 Device얻기 
            //Device device = DeviceManager.GetInstance().GetDevice("COM15");
            for (int i = 0; i < 20; i++)
            {
                Device device = DeviceManager.GetInstance().GetDevice("COM" + i);
                if (device == null)
                {
                    continue;
                }
                else
                {
                    device.OnReceive += DataReceived;
                }
            }
        }
        private void DataReceived(object sender, ExtensionEventArgs e)
        {
            this.Invoke(new Action(()=>
            {
                string receivedString = e.GetSourceId() + ":" + Encoding.Default.GetString(e.GetReceiveData());
                ListViewItem lvi = new ListViewItem();
                lvi.Text = receivedString;
                lvi.SubItems.Add(receivedString);
                listViewReceived.Items.Add(lvi);
            }));


        }

        private void DoSomeThing()
        {
            ListViewFileCreator listViewFileCreator = new XMLFile();
            listViewFileCreator.MakeFile();
        }

    }
}
